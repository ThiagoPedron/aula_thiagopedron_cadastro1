<!DOCTYPE html>
<html>
<head>
	<title>Listar</title>
	<link rel="stylesheet" href="css/style.css">
	<meta charset="utf-8">
</head>
<body style="background-image: url(img/fundo.jpg); background-size: cover; ">

	<?php 

			$sql= "SELECT * FROM contatos_tb ORDER BY nome";
			include "conexao.php";
			$contatos = $fusca -> prepare($sql);
			$contatos -> execute();

	 ?>
	<center>
	<h1 align="center"><b>Listar Contatos</b></h1>
	<hr>
	<table border="1" align="center">
		<tr>
			<th>Nome</th>
			<th>Telefone</th>
			<th>Endereco</th>
			<th>Email</th>
			<th>Sexo</th>
			<th>Observacao</th>
			<th colspan="2
			">OP</th>
			<?php

			foreach ($contatos as $bolacha) {

				$id = $bolacha['id'];
				$nome= $bolacha['nome'];
				$telefone= $bolacha['telefone'];
				$endereco= $bolacha['endereco'];
				$email= $bolacha['email'];
				$sexo= $bolacha['sexo'];
				$obs= $bolacha['obs'];


				echo "<tr>";
				echo "<td>".$nome."</td><td>".$telefone."</td><td>".$endereco."</td><td>".$email."</td><td>".$sexo."</td><td>".$obs."</td><br>";
				echo "<td><a href='editar.php?id=$id'><img src = 'icons/edit.png' width='25px' height='25px' title='Editar usuario'></a></td>";
				echo "<td><a href='excluir.php?id=$id'><img src = 'icons/delete.png' width='25px' height='25px' title='Excluir usuario $nome'></a></td>";
				echo "</tr>";
			}	


			?>
		</tr>
	</table>
	<button><a href="agenda_bd.php">Voltar</a></button>
	</center>
</body>
</html>