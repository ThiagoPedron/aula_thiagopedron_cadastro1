<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Editar</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body style="background-image: url(img/fundo.jpg); background-size: cover;">
	<?php

		$id = $_GET['id'];
		$sql = "SELECT * FROM contatos_tb WHERE id = $id";
		include "conexao.php";
		$contatos = $fusca -> prepare($sql);
		$contatos -> execute();
		foreach ($contatos as $bolacha) {

				$id = $bolacha['id'];
				$nome = $bolacha['nome'];
				$telefone = $bolacha['telefone'];
				$endereco = $bolacha['endereco'];
				$email = $bolacha['email'];
				$sexo = $bolacha['sexo'];
				$obs = $bolacha['obs'];
		 }

	//	===========================================
			
		if(isset($_POST['salvar'])){

			@$id = "";
			@$nome = $_POST['nome'];
			@$telefone = $_POST['telefone'];
			@$endereco = $_POST['endereco'];
			@$email = $_POST['email'];
			@$sexo = $_POST['sexo'];
			@$obs = $_POST['obs'];


			$sql =
			"UPDATE agenda_tb SET 
			 nome  			= ?,
			 telefone 		= ?,
			 endereco		= ?,
			 email  		= ?,
			 sexo 			= ?,
			 obs 			= ?
			 where id_contato = ? ";

			 $contatos = $fusca -> prepare($sql);
			 $contatos -> execute(array($nome, $telefone, $endereco, $email, $sexo, $obs, $id));
			 $contatos = NULL;
			 header("Location: listar.php");
		}
	?>
		
		<center>
			<h1 align="center"><b>Editar Contatos</b></h1>
			
				<form action="agenda_bd.php" method="POST">
					<center>
						<table>
							<tr>
								<td>
									<fieldset align="center">
										<legend>Dados Pessoais</legend>
											<table>
												<tr>
													<td colspan="2">
														*Nome:<br>
														<input type="text" name="nome" autofocus  title="apenas letras" value="<?php echo $bolacha['nome']; ?>" pattern="[a-z\s]+$" style="width:100%;"><br>
													</td>
												</tr>
												<tr>
													<td>
														*Telefone:<br>
														<input type="text" name="telefone"  title="Apenas números" value="<?php echo $telefone; ?>" pattern="[0-9\s]+$" maxlength="11" style="width:100%;"O><br>
													</td>
												</tr>
												<tr>
													<td>
														*Endereço:<br>
														<input type="text" name="endereco" title="Apenas letras" value="<?php echo $endereco; ?>" style="width:100%;"><br>
													</td>
												</tr>
												<tr>
													<td>
														*Email:<input type="email" name="email" value="<?php echo $email; ?>" style=" width : 100%; "><br>
													</td>
												</tr>
												<tr>
													<td>
														*Sexo:<br>
														M<input type="radio" name="sexo" checked value="Masculino">
														F<input type="radio" name="sexo" value="Feminino"><br><br>
													</td>
												</tr>
												
												<tr>
													<td>
														Observações:<br><textarea value="<?php echo $obs; ?>" name="obs" style=" height: 100px; width: 100%;"></textarea>
													</td>
												</tr>
											</table>
										<br>
										<input type="submit" value="Próximo" name="avancar" class="botao">
										<a href="listar.php"><input type="button" name="mostrar" value="Listar"></a>
									</fieldset>
								</td>
							</tr>	
						</table>
					</center>	

				</form>

		</center>	
</body>
</html>