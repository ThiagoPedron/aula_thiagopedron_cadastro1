<<?php 

	try{
		$fusca= new PDO("mysql:host=localhost; dbname=agenda_tb","root","");
		echo "Conexao efetuada";
	}
	catch(PDOException $e){
		echo $e->getMessage();
	}



 ?>