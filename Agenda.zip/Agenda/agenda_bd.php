<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>Index</title>
		<link rel="stylesheet" href="css/style.css">
	</head>
	<body  style="background-image: url(img/fundo.jpg); background-size: cover;">

		<?php 

			if (isset($_POST["Avancar"])) {

				@$id = "";
				@$nome = $_POST['nome'];
				@$telefone = $_POST['telefone'];
				@$endereco = $_POST['endereco'];
				@$email = $_POST['email'];
				@$sexo = $_POST['sexo'];
				@$obs = $_POST['obs'];

				include "conexao.php";

				$sql= "INSERT INTO contatos_tb VALUES (?,?,?,?,?,?,?)";
				$contatos = $fusca -> prepare($sql);
				$contatos -> execute(array($id,$nome,$telefone,$endereco,$email,$sexo,$obs));
				$contatos = null;
				header("Location: listar.php");
			}


		 ?>

		<center>
		<h1 align="center"><b>Agenda</b></h1>
		<hr>
		<form method="post">
			<table align="center" >
				<tr>
					<td>
						<br><br><br><br>
						<fieldset>
							
								<table>
									<tr>
										<td colspan="2">
											Nome:<br>
											<input type="text" name="nome" autofocus required placeholder="Nome"  style="width:332px;">
										</td>
									</tr>
									<tr>
										<td>
											Telefone:<br>
											<input type="text" name="telefone" required placeholder="Telefone"  style="width:332px;">
										</td>
									</tr>
									<tr>
										<td>
											Endereço:<br>
											<input type="text" name="endereco" required placeholder="Endereço"  style="width:332px;">
										</td>
									</tr>
									<tr>
										<td>
											E-Mail:<br>
											<input type="text" name="email" required placeholder="E-Mail"  style="width:332px;">
										</td>
									<tr>
										<td>
											Sexo:<br>
											<input type="radio" name="sexo" value="M">Masculino 
											<input type="radio" name="sexo" value="F">Feminino
										</td>
									</tr>
									<tr>
										<td>
											Observações:<br>
											<textarea name="obs" placeholder="Obserções" style="width: 300px; height: 150px;"></textarea>
										</td>
									</tr>
								</table>
							<br>
							

						</fieldset>
						<center>
							<input type="submit" name="Avancar" value="Avancar" align="center">
							<button><a href="listar.php">Listar</a></button>
							<input type="reset" value="Limpar" align="center">
						</center>
					</td>
				</tr>	
			</table>

		</form>
	</center>
</body>