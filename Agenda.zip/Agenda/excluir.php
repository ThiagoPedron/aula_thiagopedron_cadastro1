<?php 
	$id = $_GET['id'];
	echo "Id capturado: ".$id;

	$sql = "DELETE  FROM contatos_tb WHERE id =$id";

	include "conexao.php";

	$contatos = $fusca -> prepare($sql);
	$contatos -> execute();
	header("Location: listar.php");

?>