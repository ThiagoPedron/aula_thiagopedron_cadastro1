-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 06-Set-2016 às 17:00
-- Versão do servidor: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `agenda_tb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `contatos_tb`
--

CREATE TABLE IF NOT EXISTS `contatos_tb` (
`id` int(3) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `sexo` varchar(1) DEFAULT NULL,
  `obs` varchar(120) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `contatos_tb`
--

INSERT INTO `contatos_tb` (`id`, `nome`, `telefone`, `endereco`, `email`, `sexo`, `obs`) VALUES
(6, 'Vicente', '(41)5478-8802', 'rua do barulho', 'vicente@gmail.com', 'M', 'Obs Vicente'),
(8, 'Souza', '123568', 'rua Souza', '245', 'F', 'gewfew'),
(10, 'thiago', '33482805', 'rua pedrsfkÂ´ps', 'thiago70@gmail.com', 'M', 'obs de thiago'),
(11, 'joÃ£o', '424242545223', 'rua sla', 'thiago@gmail.com', 'M', 'obs de joao');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contatos_tb`
--
ALTER TABLE `contatos_tb`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contatos_tb`
--
ALTER TABLE `contatos_tb`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
